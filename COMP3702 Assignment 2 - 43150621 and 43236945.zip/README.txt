Assignment 2 COMP3702 Instructions on Compiling
Student Name: Joshua Rillera, Thomas Millward
Student Number: 43150621, 43236945
Date Due: 11:59, 17th of October, 2015

Instructions
- Our assignment can be compiled to a2-3702.jar 
	by simply running the command, "ant", in the command 
	line whilst in the same directory as this readme. 
- The configuration for the ant build can be found in: "build.xml"
	within this directory
- Once the command, "ant", is run, a jar executable will be made which 
can be run in the command line like so:

java -jar a2-3702.jar [Input File Path] [Output File Path]